CLI for automatic setting up of amar_jay's dev setup
- TMUX
- Neovim (LazyVim)
